﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYNTRA.Models;
namespace MYNTRA
{
    public partial class Dashboard : Form
    {
        Customer cust = new Customer();
        public Dashboard()
        {
            InitializeComponent();
        }
        public Dashboard(Customer c)
        {
            InitializeComponent();
            cust = c;
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            label1.Text = "WELCOME " + cust.Fullname;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
