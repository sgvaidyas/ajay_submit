﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYNTRA.Models;
namespace MYNTRA
{
    public partial class Login : Form
    {
        CredentialsLogic ob = new CredentialsLogic();
        public Login()
        {
            InitializeComponent();
        }
        //login 
        private void btnlogin_Click(object sender, EventArgs e)
        {
            string user = txtusername.Text.ToString();
            string passd = txtPassword.Text.ToString();

            Customer cust = null;
            int isValid = ob.isvaliduser(user,passd,out cust);

            if (isValid == 0)
                MessageBox.Show("Email does not exist, click sign up ");
            else if(isValid==1)
            {
                MessageBox.Show("Email exists, Reeneter the correct password ");
                txtPassword.Text = "";
            }
            else if(isValid==2)
            {
                MessageBox.Show("LOGIN SUCCESSFULL");
                MessageBox.Show(cust.ToString());
                Dashboard db = new Dashboard(cust);
                db.Show();
            }
            else
            {
                MessageBox.Show("PROBLEM IN ESTABLISHING CONNECTION");
            }
        }

        private void linkSignup_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string email = txtusername.Text;
            Signup sp = new Signup(email);
            sp.Show();
            this.Hide();
        }
    }
}
