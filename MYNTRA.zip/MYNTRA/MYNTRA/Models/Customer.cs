﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MYNTRA.Models
{
    public class Customer
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string Fullname { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string SecurityAns { get; set; }

        public override string ToString()
        {
            string cust = "";

            cust += " EMAIL =" + Email;
            cust += "\n Password =" + Password;
            cust += "\n Fullname =" + Fullname;
            cust += "\n Phone =" + Phone;
            cust += "\n Address =" + Address;
            return cust;
        }
    }
}
