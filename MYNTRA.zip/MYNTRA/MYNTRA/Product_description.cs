﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYNTRA
{
    public partial class Product_description : Form
    {
        public Product_description()
        {
            InitializeComponent();
        }

        private void Product_description_Load(object sender, EventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(Application.StartupPath);
            string imgpath = (((di.Parent).Parent.FullName) + "\\images\\");
            pictureBox1.Image = Image.FromFile(imgpath + "e1.jpg");
        }
    }
}
